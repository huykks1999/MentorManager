package com.vti.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vti.entity.ClassRequest;

public interface IClassRequestRepository extends JpaRepository<ClassRequest, Short> {

}
