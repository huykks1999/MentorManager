package com.vti.service;

public interface IAdminService {
	public boolean isGroupExistsByID(short id);

	public boolean isGroupExistsByName(String name);
}
