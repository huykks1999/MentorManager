package com.vti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagerMentorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagerMentorApplication.class, args);
	}

}
