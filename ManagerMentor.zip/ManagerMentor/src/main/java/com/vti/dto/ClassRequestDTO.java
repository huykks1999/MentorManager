package com.vti.dto;

public class ClassRequestDTO {

}
