package com.vti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagerMentorApplicationTests {

	@Test
	void contextLoads() {
	}

}
